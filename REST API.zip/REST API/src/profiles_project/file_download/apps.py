from django.apps import AppConfig


class FileDownloadConfig(AppConfig):
    name = 'file_download'
